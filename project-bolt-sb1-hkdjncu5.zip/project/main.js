import './style.css'
import * as faceapi from 'face-api.js';

// 获取上传区域和文件输入元素
const dropZone = document.querySelector('.border-dashed');
const fileInput = document.querySelector('#photo');
let isModelLoaded = false;

// 加载人脸识别模型
async function loadModels() {
  try {
    await faceapi.nets.ssdMobilenetv1.loadFromUri('/models');
    await faceapi.nets.faceLandmark68Net.loadFromUri('/models');
    isModelLoaded = true;
  } catch (error) {
    console.error('模型加载失败:', error);
  }
}

// 检查图片质量
function checkImageQuality(image) {
  return new Promise((resolve) => {
    const minWidth = 200;
    const minHeight = 200;
    
    if (image.width < minWidth || image.height < minHeight) {
      resolve({
        isValid: false,
        message: '图片分辨率太低，请上传至少 200x200 像素的图片'
      });
      return;
    }

    // 创建 canvas 检查图片清晰度
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = image.width;
    canvas.height = image.height;
    ctx.drawImage(image, 0, 0);
    
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    
    // 计算拉普拉斯边缘检测来评估清晰度
    let blurScore = 0;
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      blurScore += Math.abs(r - g) + Math.abs(g - b) + Math.abs(b - r);
    }
    blurScore = blurScore / (image.width * image.height);

    resolve({
      isValid: blurScore > 20,
      message: blurScore <= 20 ? '图片太模糊，请上传更清晰的照片' : ''
    });
  });
}

// 检测人脸
async function detectFace(image) {
  if (!isModelLoaded) {
    await loadModels();
  }

  const detections = await faceapi.detectAllFaces(image)
    .withFaceLandmarks();

  if (!detections.length) {
    return {
      isValid: false,
      message: '未能检测到人脸，请上传包含清晰人脸的照片'
    };
  }

  if (detections.length > 1) {
    return {
      isValid: false,
      message: '检测到多个人脸，请只上传一个人脸的照片'
    };
  }

  // 检查人脸是否正面
  const landmarks = detections[0].landmarks;
  const nose = landmarks.getNose();
  const jawline = landmarks.getJawOutline();
  
  // 简单的人脸角度检查
  const faceAngle = Math.abs(nose[3].x - (jawline[0].x + jawline[16].x) / 2);
  if (faceAngle > 20) {
    return {
      isValid: false,
      message: '请上传正面人脸照片'
    };
  }

  return {
    isValid: true,
    message: ''
  };
}

// 处理文件上传
async function handleFile(file) {
  if (!file.type.startsWith('image/')) {
    alert('请上传图片文件！');
    return;
  }

  const reader = new FileReader();
  reader.onload = async function(e) {
    const image = new Image();
    image.src = e.target.result;
    
    image.onload = async function() {
      // 检查图片质量
      const qualityCheck = await checkImageQuality(image);
      if (!qualityCheck.isValid) {
        alert(qualityCheck.message);
        return;
      }

      // 检测人脸
      const faceCheck = await detectFace(image);
      if (!faceCheck.isValid) {
        alert(faceCheck.message);
        return;
      }

      // 显示预览图片
      const preview = document.createElement('img');
      preview.src = e.target.result;
      preview.className = 'max-w-full h-auto rounded-lg mb-4';
      
      // 清空拖放区域并添加预览图片
      dropZone.innerHTML = '';
      dropZone.appendChild(preview);
      
      // 添加重新上传提示
      const resetText = document.createElement('p');
      resetText.className = 'text-sm text-gray-500 mt-2';
      resetText.textContent = '点击更换图片';
      dropZone.appendChild(resetText);
    };
  };
  
  reader.readAsDataURL(file);
}

// 点击上传
dropZone.addEventListener('click', () => {
  fileInput.click();
});

// 文件输入改变事件
fileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (file) {
    handleFile(file);
  }
});

// 拖放功能
dropZone.addEventListener('dragover', (e) => {
  e.preventDefault();
  dropZone.classList.add('border-blue-500');
});

dropZone.addEventListener('dragleave', (e) => {
  e.preventDefault();
  dropZone.classList.remove('border-blue-500');
});

dropZone.addEventListener('drop', (e) => {
  e.preventDefault();
  dropZone.classList.remove('border-blue-500');
  
  const file = e.dataTransfer.files[0];
  if (file) {
    handleFile(file);
  }
});

// 初始加载模型
loadModels();